The codes in this folder are for the model compuatations.  All Fortran codes are written in Fortran 90, and they are made sure to run in Intel Fortran 2007 with IMSL version (operating system: Windows 10).  All Matlab codes are run in Matlab R2017a.

This folder contains the codes for the General Equilibrium analysis for Sections 4, 5, 6, and 7. 

First, the Fortran codes under steady_state folder has to be run (one hour in my laptop with Intel Core i7 2.90GHz, 16GBRAM).  That generates the Model statistics in Table 5, and inputs for the transition codes later.

Second, run the fortran codes in three subfolders (separately) under transitions folder.  Before running, the output files from the steady_state codes have to be put in the input folder that can be called by the program.  Each set of codes are expected to run for 5 to 10 hours.

Third, put the outputs from the previous fortran codes to the folders called A, Lam, and Sig (corresponding to A, lambda, sigma codes).  Also put the hpfilter.m code.  Then run simulateA.m code (under the matlab subfolder) to obtain the output file stats_MA.txt, which contains information to produce Tables 6 and 7.  Run simulateE to obtain the output file stats_M.txt, to produce Tables 9 and 10.  For the decomposition analysis, run simulateE_decA.m (TFP shocks), simulateE_decL.m (job-finding rate shocks), and simulateE_decS.m (separation shocks) to obtain the outputs that can generate Tables 11 and 12.   Run simulate_noTFP.m to produce the output file for Tables 17 and 18.  Run simulate_deNUN.m to generate the output file for Tables A7 and A8.  (All Matlab codes take under one minute to run.)

