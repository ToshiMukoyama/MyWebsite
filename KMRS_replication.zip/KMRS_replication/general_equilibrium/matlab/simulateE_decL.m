clear all;
% simulate the series of epsilon

loadingL=0.21;
%loadingS=-0.3;
loadingS=0.0;
%loadingA=0.67;
loadingA=0.0;

Nperiod=6000;
skip=1000;

%generate shocks
rng(1);
shockz=zeros(1,Nperiod);
for i = 1:Nperiod
    shockz(i)=randn;
end

%load time series and convert to percent terms
%Lambda shock
dLflowEU=zeros(1,skip);
dLflowEN=zeros(1,skip);
dLflowUE=zeros(1,skip);
dLflowUN=zeros(1,skip);
dLflowNE=zeros(1,skip);
dLflowNU=zeros(1,skip);
dLY=zeros(1,skip);
dLudata=zeros(1,skip);
dLlfpr=zeros(1,skip);
dLE=zeros(1,skip);

load Lam\Ydata.txt
load Lam\uratedata.txt
load Lam\lfprdata.txt
load Lam\Edata.txt

load Lam\flowEU.txt
load Lam\flowEN.txt
load Lam\flowUE.txt
load Lam\flowUN.txt
load Lam\flowNE.txt
load Lam\flowNU.txt

for i=1:skip
dLflowEU(i)=log(flowEU(i))-log(flowEU(skip));
dLflowEN(i)=log(flowEN(i))-log(flowEN(skip));
dLflowUE(i)=log(flowUE(i))-log(flowUE(skip));
dLflowUN(i)=log(flowUN(i))-log(flowUN(skip));
dLflowNE(i)=log(flowNE(i))-log(flowNE(skip));
dLflowNU(i)=log(flowNU(i))-log(flowNU(skip));
dLY(i)=log(Ydata(i))-log(Ydata(skip));
dLudata(i)=log(uratedata(i))-log(uratedata(skip));
dLlfpr(i)=log(lfprdata(i))-log(lfprdata(skip));
dLE(i)=log(Edata(i))-log(Edata(skip));
end

%Sigma shock
dSflowEU=zeros(1,skip);
dSflowEN=zeros(1,skip);
dSflowUE=zeros(1,skip);
dSflowUN=zeros(1,skip);
dSflowNE=zeros(1,skip);
dSflowNU=zeros(1,skip);
dSY=zeros(1,skip);
dSudata=zeros(1,skip);
dSlfpr=zeros(1,skip);
dSE=zeros(1,skip);

load Sig\Ydata.txt
load Sig\uratedata.txt
load Sig\lfprdata.txt
load Sig\Edata.txt

load Sig\flowEU.txt
load Sig\flowEN.txt
load Sig\flowUE.txt
load Sig\flowUN.txt
load Sig\flowNE.txt
load Sig\flowNU.txt

for i=1:skip
dSflowEU(i)=log(flowEU(i))-log(flowEU(skip));
dSflowEN(i)=log(flowEN(i))-log(flowEN(skip));
dSflowUE(i)=log(flowUE(i))-log(flowUE(skip));
dSflowUN(i)=log(flowUN(i))-log(flowUN(skip));
dSflowNE(i)=log(flowNE(i))-log(flowNE(skip));
dSflowNU(i)=log(flowNU(i))-log(flowNU(skip));
dSY(i)=log(Ydata(i))-log(Ydata(skip));
dSudata(i)=log(uratedata(i))-log(uratedata(skip));
dSlfpr(i)=log(lfprdata(i))-log(lfprdata(skip));
dSE(i)=log(Edata(i))-log(Edata(skip));
end



%A shock
dAflowEU=zeros(1,skip);
dAflowEN=zeros(1,skip);
dAflowUE=zeros(1,skip);
dAflowUN=zeros(1,skip);
dAflowNE=zeros(1,skip);
dAflowNU=zeros(1,skip);
dAY=zeros(1,skip);
dAudata=zeros(1,skip);
dAlfpr=zeros(1,skip);
dAE=zeros(1,skip);

load A\Ydata.txt
load A\uratedata.txt
load A\lfprdata.txt
load A\Edata.txt

load A\flowEU.txt
load A\flowEN.txt
load A\flowUE.txt
load A\flowUN.txt
load A\flowNE.txt
load A\flowNU.txt

for i=1:skip
dAflowEU(i)=log(flowEU(i))-log(flowEU(skip));
dAflowEN(i)=log(flowEN(i))-log(flowEN(skip));
dAflowUE(i)=log(flowUE(i))-log(flowUE(skip));
dAflowUN(i)=log(flowUN(i))-log(flowUN(skip));
dAflowNE(i)=log(flowNE(i))-log(flowNE(skip));
dAflowNU(i)=log(flowNU(i))-log(flowNU(skip));
dAY(i)=log(Ydata(i))-log(Ydata(skip));
dAudata(i)=log(uratedata(i))-log(uratedata(skip));
dAlfpr(i)=log(lfprdata(i))-log(lfprdata(skip));
dAE(i)=log(Edata(i))-log(Edata(skip));
end



dflowEU=zeros(1,Nperiod-skip);
dflowEN=zeros(1,Nperiod-skip);
dflowUE=zeros(1,Nperiod-skip);
dflowUN=zeros(1,Nperiod-skip);
dflowNE=zeros(1,Nperiod-skip);
dflowNU=zeros(1,Nperiod-skip);
dY=zeros(1,Nperiod-skip);
dudata=zeros(1,Nperiod-skip);
dlfpr=zeros(1,Nperiod-skip);
dE=zeros(1,Nperiod-skip);


for i=1:Nperiod-skip
    for j=1:skip
        n=skip+1-j;
        dflowEU(i)=dflowEU(i)+(dLflowEU(n)*loadingL+dSflowEU(n)*loadingS+dAflowEU(n)*loadingA)*shockz(i+j-1);
        dflowEN(i)=dflowEN(i)+(dLflowEN(n)*loadingL+dSflowEN(n)*loadingS+dAflowEN(n)*loadingA)*shockz(i+j-1);
        dflowUE(i)=dflowUE(i)+(dLflowUE(n)*loadingL+dSflowUE(n)*loadingS+dAflowUE(n)*loadingA)*shockz(i+j-1);
        dflowUN(i)=dflowUN(i)+(dLflowUN(n)*loadingL+dSflowUN(n)*loadingS+dAflowUN(n)*loadingA)*shockz(i+j-1);
        dflowNE(i)=dflowNE(i)+(dLflowNE(n)*loadingL+dSflowNE(n)*loadingS+dAflowNE(n)*loadingA)*shockz(i+j-1);
        dflowNU(i)=dflowNU(i)+(dLflowNU(n)*loadingL+dSflowNU(n)*loadingS+dAflowNU(n)*loadingA)*shockz(i+j-1);
        dY(i)=dY(i)+(dLY(n)*loadingL+dSY(n)*loadingS+dAY(n)*loadingA)*shockz(i+j-1);
        dudata(i)=dudata(i)+(dLudata(n)*loadingL+dSudata(n)*loadingS+dAudata(n)*loadingA)*shockz(i+j-1);
        dlfpr(i)=dlfpr(i)+(dLlfpr(n)*loadingL+dSlfpr(n)*loadingS+dAlfpr(n)*loadingA)*shockz(i+j-1);
        dE(i)=dE(i)+(dLE(n)*loadingL+dSE(n)*loadingS+dAE(n)*loadingA)*shockz(i+j-1);
    end
end

flowEU=exp(dflowEU);
flowEN=exp(dflowEN);
flowUE=exp(dflowUE);
flowUN=exp(dflowUN);
flowNE=exp(dflowNE);
flowNU=exp(dflowNU);

Ydata=exp(dY);
uratedata=exp(dudata);
urate_m=uratedata;
lfpr_m=exp(dlfpr);
Edata=exp(dE);

Nskip = 1000;

j = 1;

for i=Nskip+1:3:size(uratedata,2)-2
  j = j+1;
end  
urate=zeros(1,j-1);
lfpr=zeros(1,j-1);
E=zeros(1,j-1);
fnu=zeros(1,j-1);
fun=zeros(1,j-1);
fne=zeros(1,j-1);
fen=zeros(1,j-1);
fue=zeros(1,j-1);
feu=zeros(1,j-1);
Y=zeros(1,j-1);
j = 1;
for i=Nskip+1:3:size(uratedata,2)-2
  urate(j) = mean(urate_m(i:i+2));
  lfpr(j) = mean(lfpr_m(i:i+2));
  E(j) = mean(Edata(i:i+2));
  fnu(j) = mean(flowNU(i:i+2));
  fun(j) = mean(flowUN(i:i+2));
  fne(j) = mean(flowNE(i:i+2));
  fen(j) = mean(flowEN(i:i+2));
  fue(j) = mean(flowUE(i:i+2));
  feu(j) = mean(flowEU(i:i+2));
  j = j+1;
end  

j=1;

for i=Nskip+1:3:size(Ydata,2)-2
  Y(j) = sum(Ydata(i:i+2));
  j = j+1;
end  


trends_y = hpfilter(log(Y), 1600);
cyclical_y = log(Y)-trends_y' ;
std_Y = std(cyclical_y);
autocorr_Y= corrcoef(cyclical_y(1:end-1),cyclical_y(2:end));


trends_E= hpfilter(log(E),1600);    
cyclical_E= log(E)-trends_E';
std_E = std(cyclical_E);
autocorr_E= corrcoef(cyclical_E(1:end-1),cyclical_E(2:end));

trends_urate= hpfilter(log(urate),1600);    
cyclical_urate= log(urate)-trends_urate';
std_urate = std(cyclical_urate);
autocorr_urate= corrcoef(cyclical_urate(1:end-1),cyclical_urate(2:end));


trends_lfpr= hpfilter(log(lfpr),1600);    
cyclical_lfpr= log(lfpr)-trends_lfpr';
std_lfpr = std(cyclical_lfpr);
autocorr_lfpr= corrcoef(cyclical_lfpr(1:end-1),cyclical_lfpr(2:end));


trends_feu= hpfilter(log(feu),1600);    
cyclical_feu= log(feu)-trends_feu';
std_feu = std(cyclical_feu);
autocorr_feu= corrcoef(cyclical_feu(1:end-1),cyclical_feu(2:end));

trends_fen= hpfilter(log(fen),1600);    
cyclical_fen= log(fen)-trends_fen';
std_fen = std(cyclical_fen);
autocorr_fen= corrcoef(cyclical_fen(1:end-1),cyclical_fen(2:end));

trends_fue= hpfilter(log(fue),1600);    
cyclical_fue= log(fue)-trends_fue';
std_fue = std(cyclical_fue);
autocorr_fue= corrcoef(cyclical_fue(1:end-1),cyclical_fue(2:end));


trends_fun= hpfilter(log(fun),1600);    
cyclical_fun= log(fun)-trends_fun';
std_fun = std(cyclical_fun);
autocorr_fun= corrcoef(cyclical_fun(1:end-1),cyclical_fun(2:end));


trends_fne= hpfilter(log(fne),1600);    
cyclical_fne= log(fne)-trends_fne';
std_fne = std(cyclical_fne);
autocorr_fne= corrcoef(cyclical_fne(1:end-1),cyclical_fne(2:end));


trends_fnu= hpfilter(log(fnu),1600);    
cyclical_fnu= log(fnu)-trends_fnu';
std_fnu = std(cyclical_fnu);
autocorr_fnu= corrcoef(cyclical_fnu(1:end-1),cyclical_fnu(2:end));

%trends_avglsu = hpfilter(avglsu, 1600);
%cyclical_avglsu = avglsu-trends_avglsu' ;
%std_avglsu = std(cyclical_avglsu);

%trends_stdlse = hpfilter(log(stdlse), 1600);
%cyclical_stdlse = log(stdlse)-trends_stdlse' ;
%std_stdlse = std(cyclical_stdlse);

% Statistics with respect to output
fid = fopen('stats_M_decL.txt','w');
%fprintf(fid, 'std_Y ');
%fprintf(fid,'%1.3f\n',std_Y);

std_EY = std_E/std_Y;
X = corrcoef(cyclical_y,cyclical_E);
corr_EY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_E(2:end));
corr_EYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_E(1:end-1));
corr_EYminus1 = X(1,2);
%fprintf(fid, 'std_EY ');
%fprintf(fid,'%1.3f\n',std_EY);
%fprintf(fid, 'corr_EY ');
%fprintf(fid,'%1.3f\n',corr_EY);
%fprintf(fid, 'corr_EYplus1 ');
%fprintf(fid,'%1.3f\n',corr_EYplus1);
%fprintf(fid, 'corr_EYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_EYminus1);


std_urateY = std_urate/std_Y;
X = corrcoef(cyclical_y,cyclical_urate);
corr_urateY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_urate(2:end));
corr_urateYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_urate(1:end-1));
corr_urateYminus1 = X(1,2);
%fprintf(fid, 'std_urateY ');
%fprintf(fid,'%1.3f\n',std_urateY);
%fprintf(fid, 'corr_urateY ');
%fprintf(fid,'%1.3f\n',corr_urateY);
%fprintf(fid, 'corr_urateYplus1 ');
%fprintf(fid,'%1.3f\n',corr_urateYplus1);
%fprintf(fid, 'corr_urateYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_urateYminus1);

std_lfprY = std_lfpr/std_Y;
X = corrcoef(cyclical_y,cyclical_lfpr);
corr_lfprY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_lfpr(2:end));
corr_lfprYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_lfpr(1:end-1));
corr_lfprYminus1 = X(1,2);
%fprintf(fid, 'std_lfprY ');
%fprintf(fid,'%1.3f\n',std_lfprY);
%fprintf(fid, 'corr_lfprY ');
%fprintf(fid,'%1.3f\n',corr_lfprY);
%fprintf(fid, 'corr_lfprYplus1 ');
%fprintf(fid,'%1.3f\n',corr_lfprYplus1);
%fprintf(fid, 'corr_lfprYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_lfprYminus1);

std_feuY = std_feu/std_Y;
X = corrcoef(cyclical_y,cyclical_feu);
corr_feuY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_feu(2:end));
corr_feuYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_feu(1:end-1));
corr_feuYminus1 = X(1,2);
%fprintf(fid, 'std_feuY ');
%fprintf(fid,'%1.3f\n',std_feuY);
%fprintf(fid, 'corr_feuY ');
%fprintf(fid,'%1.3f\n',corr_feuY);
%fprintf(fid, 'corr_feuYplus1 ');
%fprintf(fid,'%1.3f\n',corr_feuYplus1);
%fprintf(fid, 'corr_feuYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_feuYminus1);



std_fenY = std_fen/std_Y;
X = corrcoef(cyclical_y,cyclical_fen);
corr_fenY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_fen(2:end));
corr_fenYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_fen(1:end-1));
corr_fenYminus1 = X(1,2);
%fprintf(fid, 'std_fenY ');
%fprintf(fid,'%1.3f\n',std_fenY);
%fprintf(fid, 'corr_fenY ');
%fprintf(fid,'%1.3f\n',corr_fenY);
%fprintf(fid, 'corr_fenYplus1 ');
%fprintf(fid,'%1.3f\n',corr_fenYplus1);
%fprintf(fid, 'corr_fenYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fenYminus1);


std_fueY = std_fue/std_Y;
X = corrcoef(cyclical_y,cyclical_fue);
corr_fueY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_fue(2:end));
corr_fueYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_fue(1:end-1));
corr_fueYminus1 = X(1,2);
%fprintf(fid, 'std_fueY ');
%fprintf(fid,'%1.3f\n',std_fueY);
%fprintf(fid, 'corr_fueY ');
%fprintf(fid,'%1.3f\n',corr_fueY);
%fprintf(fid, 'corr_fueYplus1 ');
%fprintf(fid,'%1.3f\n',corr_fueYplus1);
%fprintf(fid, 'corr_fueYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fueYminus1);



std_funY = std_fun/std_Y;
X = corrcoef(cyclical_y,cyclical_fun);
corr_funY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_fun(2:end));
corr_funYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_fun(1:end-1));
corr_funYminus1 = X(1,2);
%fprintf(fid, 'std_funY ');
%fprintf(fid,'%1.3f\n',std_funY);
%fprintf(fid, 'corr_funY ');
%fprintf(fid,'%1.3f\n',corr_funY);
%fprintf(fid, 'corr_funYplus1 ');
%fprintf(fid,'%1.3f\n',corr_funYplus1);
%fprintf(fid, 'corr_funYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_funYminus1);


std_fneY = std_fne/std_Y;
X = corrcoef(cyclical_y,cyclical_fne);
corr_fneY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_fne(2:end));
corr_fneYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_fne(1:end-1));
corr_fneYminus1 = X(1,2);
%fprintf(fid, 'std_fneY ');
%fprintf(fid,'%1.3f\n',std_fneY);
%fprintf(fid, 'corr_fneY ');
%fprintf(fid,'%1.3f\n',corr_fneY);
%fprintf(fid, 'corr_fneYplus1 ');
%fprintf(fid,'%1.3f\n',corr_fneYplus1);
%fprintf(fid, 'corr_fneYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fneYminus1);


std_fnuY = std_fnu/std_Y;
X = corrcoef(cyclical_y,cyclical_fnu);
corr_fnuY = X(1,2);
X = corrcoef(cyclical_y(1:end-1),cyclical_fnu(2:end));
corr_fnuYplus1 = X(1,2);
X = corrcoef(cyclical_y(2:end),cyclical_fnu(1:end-1));
corr_fnuYminus1 = X(1,2);
%fprintf(fid, 'std_fnuY ');
%fprintf(fid,'%1.3f\n',std_fnuY);
%fprintf(fid, 'corr_fnuY ');
%fprintf(fid,'%1.3f\n',corr_fnuY);
%fprintf(fid, 'corr_fnuYplus1 ');
%fprintf(fid,'%1.3f\n',corr_fnuYplus1);
%fprintf(fid, 'corr_fnuYminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fnuYminus1);



%Statistics with respect to the unemployment rate

std_fenU = std_fen/std_urate;
X = corrcoef(cyclical_urate,cyclical_fen);
corr_fenU = X(1,2);
X = corrcoef(cyclical_urate(1:end-1),cyclical_fen(2:end));
corr_fenUplus1 = X(1,2);
X = corrcoef(cyclical_urate(2:end),cyclical_fen(1:end-1));
corr_fenUminus1 = X(1,2);
%fprintf(fid, 'std_fenU ');
%fprintf(fid,'%1.3f\n',std_fenU);
%fprintf(fid, 'corr_fenU ');
%fprintf(fid,'%1.3f\n',corr_fenU);
%fprintf(fid, 'corr_fenUplus1 ');
%fprintf(fid,'%1.3f\n',corr_fenUplus1);
%fprintf(fid, 'corr_fenUminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fenUminus1);



std_fueU = std_fue/std_urate;
X = corrcoef(cyclical_urate,cyclical_fue);
corr_fueU = X(1,2);
X = corrcoef(cyclical_urate(1:end-1),cyclical_fue(2:end));
corr_fueUplus1 = X(1,2);
X = corrcoef(cyclical_urate(2:end),cyclical_fue(1:end-1));
corr_fueUminus1 = X(1,2);
%fprintf(fid, 'std_fueU ');
%fprintf(fid,'%1.3f\n',std_fueU);
%fprintf(fid, 'corr_fueU ');
%fprintf(fid,'%1.3f\n',corr_fueU);
%fprintf(fid, 'corr_fueUplus1 ');
%fprintf(fid,'%1.3f\n',corr_fueUplus1);
%fprintf(fid, 'corr_fueUminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fueUminus1);


std_funU = std_fun/std_urate;
X = corrcoef(cyclical_urate,cyclical_fun);
corr_funU = X(1,2);
X = corrcoef(cyclical_urate(1:end-1),cyclical_fun(2:end));
corr_funUplus1 = X(1,2);
X = corrcoef(cyclical_urate(2:end),cyclical_fun(1:end-1));
corr_funUminus1 = X(1,2);
%fprintf(fid, 'std_funU ');
%fprintf(fid,'%1.3f\n',std_funU);
%fprintf(fid, 'corr_funU ');
%fprintf(fid,'%1.3f\n',corr_funU);
%fprintf(fid, 'corr_funUplus1 ');
%fprintf(fid,'%1.3f\n',corr_funUplus1);
%fprintf(fid, 'corr_funUminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_funUminus1);


std_fneU = std_fne/std_urate;
X = corrcoef(cyclical_urate,cyclical_fne);
corr_fneU = X(1,2);
X = corrcoef(cyclical_urate(1:end-1),cyclical_fne(2:end));
corr_fneUplus1 = X(1,2);
X = corrcoef(cyclical_urate(2:end),cyclical_fne(1:end-1));
corr_fneUminus1 = X(1,2);
%fprintf(fid, 'std_fneU ');
%fprintf(fid,'%1.3f\n',std_fneU);
%fprintf(fid, 'corr_fneU ');
%fprintf(fid,'%1.3f\n',corr_fneU);
%fprintf(fid, 'corr_fneUplus1 ');
%fprintf(fid,'%1.3f\n',corr_fneUplus1);
%fprintf(fid, 'corr_fneUminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fneUminus1);


std_fnuU = std_fnu/std_urate;
X = corrcoef(cyclical_urate,cyclical_fnu);
corr_fnuU = X(1,2);
X = corrcoef(cyclical_urate(1:end-1),cyclical_fnu(2:end));
corr_fnuUplus1 = X(1,2);
X = corrcoef(cyclical_urate(2:end),cyclical_fnu(1:end-1));
corr_fnuUminus1 = X(1,2);
%fprintf(fid, 'std_fnuU ');
%fprintf(fid,'%1.3f\n',std_fnuU);
%fprintf(fid, 'corr_fnuU ');
%fprintf(fid,'%1.3f\n',corr_fnuU);
%fprintf(fid, 'corr_fnuUplus1 ');
%fprintf(fid,'%1.3f\n',corr_fnuUplus1);
%fprintf(fid, 'corr_fnuUminus1 ');
%fprintf(fid,'%1.3f\n\n',corr_fnuUminus1);


fprintf(fid, 'std_urate ');
fprintf(fid,'%1.3f\n',std_urate);
fprintf(fid, 'std_lfpr ');
fprintf(fid,'%1.4f\n',std_lfpr);
fprintf(fid, 'std_E ');
fprintf(fid,'%1.4f\n\n',std_E);

fprintf(fid, 'corr_urateY ');
fprintf(fid,'%1.3f\n',corr_urateY);
fprintf(fid, 'corr_lfprY ');
fprintf(fid,'%1.3f\n',corr_lfprY);
fprintf(fid, 'corr_EY ');
fprintf(fid,'%1.3f\n\n',corr_EY);

fprintf(fid, 'autocorr_urate ');
fprintf(fid,'%1.3f\n',autocorr_urate(1,2));
fprintf(fid, 'autocorr_lfpr ');
fprintf(fid,'%1.3f\n',autocorr_lfpr(1,2));
fprintf(fid, 'autocorr_E ');
fprintf(fid,'%1.3f\n\n',autocorr_E(1,2));

fprintf(fid, 'std_feu ');
fprintf(fid,'%1.4f\n',std_feu);
fprintf(fid, 'std_fen ');
fprintf(fid,'%1.4f\n',std_fen);
fprintf(fid, 'std_fue ');
fprintf(fid,'%1.4f\n',std_fue);
fprintf(fid, 'std_fun ');
fprintf(fid,'%1.4f\n',std_fun);
fprintf(fid, 'std_fne ');
fprintf(fid,'%1.4f\n',std_fne);
fprintf(fid, 'std_fnu ');
fprintf(fid,'%1.4f\n',std_fnu);

fprintf(fid, 'corr_feuY ');
fprintf(fid,'%1.3f\n',corr_feuY);
fprintf(fid, 'corr_fenY ');
fprintf(fid,'%1.3f\n',corr_fenY);
fprintf(fid, 'corr_fueY ');
fprintf(fid,'%1.3f\n',corr_fueY);
fprintf(fid, 'corr_funY ');
fprintf(fid,'%1.3f\n',corr_funY);
fprintf(fid, 'corr_fneY ');
fprintf(fid,'%1.3f\n',corr_fneY);
fprintf(fid, 'corr_fnuY ');
fprintf(fid,'%1.3f\n',corr_fnuY);

fprintf(fid, 'autocorr_feu ');
fprintf(fid,'%1.3f\n',autocorr_feu(1,2));
fprintf(fid, 'autocorr_fen ');
fprintf(fid,'%1.3f\n',autocorr_fen(1,2));
fprintf(fid, 'autocorr_fue ');
fprintf(fid,'%1.3f\n',autocorr_fue(1,2));
fprintf(fid, 'autocorr_fun ');
fprintf(fid,'%1.3f\n',autocorr_fun(1,2));
fprintf(fid, 'autocorr_fne ');
fprintf(fid,'%1.3f\n',autocorr_fne(1,2));
fprintf(fid, 'autocorr_fnu ');
fprintf(fid,'%1.3f\n',autocorr_fnu(1,2));




fclose(fid);


%disp 'target: autocorr_E=0.92'

%autocorr_E

disp 'target: std_E = 0.0099'

std_E

disp 'target: std_fue = 0.088'

std_fue

disp 'target: std_feu = 0.089'

std_feu



      
  