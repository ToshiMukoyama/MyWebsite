The codes in this folder are for the model compuatations.  All Fortran codes are written in Fortran 90, and they are made sure to run in Intel Fortran 2007 with IMSL version (operating system: Windows 10).  All Matlab codes are run in Matlab R2017a.

This folder contains the codes for the Partial Equilibrium analysis for Section 7. 

First, the Fortran codes for steady_state folder has to be run.  This is the same as the one under the general_equilibrium folder.

Second, run the fortran codes in three subfolders (separately) under transitions folder.  Before running, the output files from the steady_state codes have to be put in the input folder that can be called by the program.  Each set of codes are expected to run less than 10 minutes.

Third, put the outputs from the previous fortran codes to the folders called A, Lam, and Sig (corresponding to A, lambda, sigma codes).  Also put the hpfilter.m code (under the general_equilibrium matlab folder).  Then run simulateE_PE.m code (under the matlab subfolder) to obtain the output file stats_M.txt, which contains information to produce Tables 14 and 15.   (The Matlab code takes under one minute to run.)

