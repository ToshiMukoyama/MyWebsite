function [lab]=Ex4_labor(kval,kpval,zstate,alpha,zgrid,phi,delta)

%solve for labor - use bisection
                
                %bracket between 0.2 and 0.5
                l=0.2; 
                r=0.5;
                lerr=1;
                
                while lerr>0.0001 %repeat until lerr becomes very small
                m=(l+r)/2;
                
                consl=max(zgrid(zstate)*kval^alpha*l^(1-alpha)+(1-delta)*kval-kpval,0.00001);
                consm=max(zgrid(zstate)*kval^alpha*m^(1-alpha)+(1-delta)*kval-kpval,0.00001);
                fl=(1-l)*(1-alpha)*zgrid(zstate)*kval^alpha*l^(-alpha)/consl-phi/(1-phi);
                fm=(1-m)*(1-alpha)*zgrid(zstate)*kval^alpha*m^(-alpha)/consm-phi/(1-phi);
  
    
                if sign(fl)==sign(fm)
                    l=m;
                else
                    r=m;
                end
    
                lerr=abs(l-r);
                end
 lab=m;