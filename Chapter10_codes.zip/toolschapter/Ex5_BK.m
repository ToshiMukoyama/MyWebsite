clear;
clc;
close all;

%% Parameter values
beta=0.99; % discount factor
delta=0.025; % depreciation
alpha=0.36; % capital share
Hbar=1/3; % average hours
Kbar=((1/beta-1+delta)/alpha)^(1/(alpha-1))*Hbar; % steady-state K
Cbar=Kbar^alpha*Hbar^(1-alpha)-delta*Kbar;
rho=0.95;
x=((1-Hbar)*(1-alpha)*Kbar^alpha*(Hbar)^(-alpha))/Cbar;
phi=x/(1+x) %taste parameter on labor disutility

% other steady state variables


theta = (1-Hbar)/(Hbar*(1-alpha)+alpha);

% Matrices
B = zeros(2,2);
B(1,1) = Kbar;
B(1,2) = 0;
B(2,1) = -beta*alpha*(Kbar^(alpha-1))*(Hbar^(1-alpha))*(1-alpha)*(theta*alpha-1);
B(2,2) = beta*alpha*(Kbar^(alpha-1))*(Hbar^(1-alpha))*theta*(1-alpha)+1;

A = zeros(2,2);
A(1,1) = Kbar^alpha * Hbar^(1-alpha)*(1+theta*(1-alpha))*alpha+ Kbar*(1-delta);
A(1,2) = -(Cbar + Kbar^alpha * Hbar^(1-alpha) * theta*(1-alpha));
A(2,1) = 0;
A(2,2) = 1;

E = zeros(2,1);
E(1,1) = Kbar^alpha * Hbar^(1-alpha) * (1+theta*(1-alpha));
E(2,1) = beta*alpha*Kbar^(alpha-1)*Hbar^(1-alpha)*(1+theta*(1-alpha))*rho;

F=B\A;
G=B\E;
[Htemp,Jtemp]=jordan(F);

% sort by the eigenvalue
[Jvect,ind]=sort(diag(Jtemp));
J=Jtemp(ind,ind);
H=Htemp(:,ind);

tildeH=inv(H);
Gamma=H\G;
Lambda=-1/(J(2,2)-rho);

%coefficients for c,.k', and h
ccoef1=-tildeH(2,2)^(-1)*tildeH(2,1);
ccoef2=tildeH(2,2)^(-1)*Lambda*Gamma(2);

kcoef1=F(1,1)-F(1,2)*tildeH(2,2)^(-1)*tildeH(2,1);
kcoef2=G(1)+F(1,2)*tildeH(2,2)^(-1)*Lambda*Gamma(2);

hcoef1=theta*alpha-ccoef1*theta;
hcoef2=theta-ccoef2*theta;


% impulse responses (% deviation)
IR_y=zeros(150,1);
IR_c=zeros(150,1);
IR_h=zeros(150,1);
IR_z=zeros(151,1);
IR_i=zeros(150,1);
IR_k=zeros(151,1);
tseries=1:1:150;

IR_k(1)=0;
IR_z(1)=0.007;
for time=1:150 
    IR_c(time)=ccoef1*IR_k(time)+ccoef2*IR_z(time);
    IR_h(time)=hcoef1*IR_k(time)+hcoef2*IR_z(time);
    IR_y(time)=IR_z(time)+alpha*IR_k(time)+(1-alpha)*IR_h(time);
    IR_k(time+1)=kcoef1*IR_k(time)+kcoef2*IR_z(time);
    IR_i(time)=(IR_k(time+1)-(1-delta)*IR_k(time))/delta;
    IR_z(time+1)=rho*IR_z(time);
end 

% Set up LaTeX rendering globally
set(groot, 'defaultTextInterpreter', 'latex');
set(groot, 'defaultAxesTickLabelInterpreter', 'latex');
set(groot, 'defaultLegendInterpreter', 'latex');

% Create figure
figure('Position', [100 100 700 500]);

% Common y-label
ylabel_text = '\% deviation from SS';

fs_title = 13;   % title font size
fs_label = 12;   % axis label font size
lw = 1.2;        % line width

% Plot Output
subplot(2,3,1)
plot(tseries, 100 * IR_y, 'k', 'LineWidth', lw);
title('$\mathrm{Output} $', 'FontSize', fs_title)
ylabel(ylabel_text, 'FontSize', fs_label)
grid on

% Plot Consumption
subplot(2,3,2)
plot(tseries, 100 * IR_c, 'k', 'LineWidth', lw);
title('$\mathrm{Consumption} $', 'FontSize', fs_title)
ylabel(ylabel_text, 'FontSize', fs_label)
grid on

% Plot Labor
subplot(2,3,3)
plot(tseries, 100 * IR_h, 'k', 'LineWidth', lw);
title('$\mathrm{Labor} $', 'FontSize', fs_title)
ylabel(ylabel_text, 'FontSize', fs_label)
grid on

% Plot TFP
subplot(2,3,4)
plot(tseries, 100 * IR_z(1:150), 'k', 'LineWidth', lw);
title('$\mathrm{TFP} $', 'FontSize', fs_title)
ylabel(ylabel_text, 'FontSize', fs_label)
grid on

% Plot Investment
subplot(2,3,5)
plot(tseries, 100 * IR_i, 'k', 'LineWidth', lw);
title('$\mathrm{Investment} $', 'FontSize', fs_title)
ylabel(ylabel_text, 'FontSize', fs_label)
grid on

% Plot Capital
subplot(2,3,6)
plot(tseries, 100 * IR_k(1:150), 'k', 'LineWidth', lw);
title('$\mathrm{Capital} $', 'FontSize', fs_title)
ylabel(ylabel_text, 'FontSize', fs_label)
grid on

% Save figure as high-resolution PNG
print(gcf, 'rbc_irfs.png', '-dpng', '-r300');

% Simulation
Nperiods=3000; % number of periods

Periods=1:1:Nperiods;
% all in logs
Kseries=zeros(Nperiods+1,1);
Hseries=zeros(Nperiods,1);
Cseries=zeros(Nperiods,1);
Iseries=zeros(Nperiods,1);
Zvalueseries=zeros(Nperiods+1,1);
Yseries=zeros(Nperiods,1);


Zvalueseries(1)=0; % first period is ss
Kseries(1)=0; % starting value

for time=1:Nperiods
Cseries(time)=ccoef1*Kseries(time)+ccoef2*Zvalueseries(time);
Hseries(time)=hcoef1*Kseries(time)+hcoef2*Zvalueseries(time);
Yseries(time)=Zvalueseries(time)+alpha*Kseries(time)+(1-alpha)*Hseries(time);
Kseries(time+1)=kcoef1*Kseries(time)+kcoef2*Zvalueseries(time);
Iseries(time)=(Kseries(time+1)-(1-delta)*Kseries(time))/delta;
eps=normrnd(0,0.007);
Zvalueseries(time+1)=rho*Zvalueseries(time)+eps;
end


% detrend
logY=Yseries(100:Nperiods);
logK=Kseries(100:Nperiods);
logC=Cseries(100:Nperiods);
logI=Iseries(100:Nperiods);
logH=Hseries(100:Nperiods);
logZ=Zvalueseries(100:Nperiods);

Ytrend=hpfilt(logY,1600);
Ktrend=hpfilt(logK,1600);
Ctrend=hpfilt(logC,1600);
Itrend=hpfilt(logI,1600);
Htrend=hpfilt(logH,1600);
Ztrend=hpfilt(logZ,1600);

Ycycle=logY-Ytrend;
Kcycle=logK-Ktrend;
Hcycle=logH-Htrend;
Ccycle=logC-Ctrend;
Icycle=logI-Itrend;
Zcycle=logZ-Ztrend;

%%
% standard deviations
stdY=100*std(Ycycle);
stdK=100*std(Kcycle);
stdH=100*std(Hcycle);
stdC=100*std(Ccycle);
stdI=100*std(Icycle);
stdZ=100*std(Zcycle);

% relative standard deviations
rel_stdY = stdY/stdY;
rel_stdK = stdK/stdY;
rel_stdH = stdH/stdY;
rel_stdC = stdC/stdY;
rel_stdI = stdI/stdY;
rel_stdZ = stdZ/stdY;

% cross-correlations
corrKY=corrcoef(Kcycle,Ycycle);
corrHY=corrcoef(Hcycle,Ycycle);
corrCY=corrcoef(Ccycle,Ycycle);
corrIY=corrcoef(Icycle,Ycycle);
corrZY=corrcoef(Zcycle,Ycycle);

% autocorrelations
acY = corr(Ycycle(2:end), Ycycle(1:end-1));
acK = corr(Kcycle(2:end), Kcycle(1:end-1));
acH = corr(Hcycle(2:end), Hcycle(1:end-1));
acC = corr(Ccycle(2:end), Ccycle(1:end-1));
acI = corr(Icycle(2:end), Icycle(1:end-1));
acZ = corr(Zcycle(2:end), Zcycle(1:end-1));


%%
% Cross-correlations with Y
corrCY = corrcoef(Ccycle, Ycycle); corrCY = corrCY(1,2);
corrIY = corrcoef(Icycle, Ycycle); corrIY = corrIY(1,2);
corrHY = corrcoef(Hcycle, Ycycle); corrHY = corrHY(1,2);
corrZY = corrcoef(Zcycle, Ycycle); corrZY = corrZY(1,2);

% Format LaTeX string
latexStr = sprintf([
'\\begin{table}[ht!]\n',...
'\\centering\n',...
'\\begin{tabular}{lcccc}\n',...
'\\hline\n',...
'Variable &  Std. Dev. (\\%%) & Relative Std. Dev. & Autocorr. & Cross-correlation with $y$ \\\\\n',...
'\\hline\n',...
'Output  & %.2f & %.0f & %.2f & %.2f \\\\\n',...
'Consumption  & %.2f & %.2f & %.2f & %.2f \\\\\n',...
'Investment  & %.2f & %.2f & %.2f & %.2f \\\\\n',...
'Hours & %.2f & %.2f & %.2f & %.2f \\\\\n',...
'TFP  & %.2f & %.2f & %.2f & %.2f \\\\\n',...
'\\hline\n',...
'\\end{tabular}\n',...
'\\caption{Second moments of the RBC model replication.}\n',...
'\\label{tab:replication_tab14_4}\n',...
'\\end{table}\n'], ...
stdY, 1.000, acY, 1.000, ...
stdC, rel_stdC, acC, corrCY, ...
stdI, rel_stdI, acI, corrIY, ...
stdH, rel_stdH, acH, corrHY, ...
stdZ, rel_stdZ, acZ, corrZY);

% Write to .tex file
fid = fopen('rbc_moments_table.tex', 'w');
fprintf(fid, '%s', latexStr);
fclose(fid);

disp('LaTeX table written to rbc_moments_table.tex');
