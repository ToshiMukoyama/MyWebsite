clear all;
close all;

mydata = xlsread('matlab_incub.xls');
pr1=mydata(:,2);
pr2=mydata(:,3);
emp=mydata(:,1);

figure
loglog(emp,pr1,'o',emp,pr2,'.')
title('Incumbent distribution against data')
xlabel('Employment')
ylabel('Pr(firms>x)')