clear all;
global r pee pjs leu len;

%The program for time aggregation correction.

%First, input: all from Fallck and Fleishman website, then seasonally
%adjusted
JSvectsa;%JS flow rate
EUvectsa;%EU flow rate
ENvectsa;%EN flow rate
UEvectsa;%UE flow rate
UNvectsa;%UN flow rate
NEvectsa;%NE flow rate
NUvectsa;%NU flow rate

n=size(JS,1);

%output vectors (lambdas)
JSlamN=zeros(n,1); %no recall
JSlamP=zeros(n,1); %perfect recall
JSlamFM=zeros(n,1); %Fujita and Moscarini
EUlam=zeros(n,1);
ENlam=zeros(n,1);
UElam=zeros(n,1);
UNlam=zeros(n,1);
NElam=zeros(n,1);
NUlam=zeros(n,1);


%first, Shimer (2012) adjustment

for i=1:n;

P=zeros(3,3);

P(2,1)=EU(i);%EU
P(3,1)=EN(i);%EN
P(1,1)=1-P(2,1)-P(3,1);%EE

P(1,2)=UE(i);%UE
P(3,2)=UN(i);%UN
P(2,2)=1-P(1,2)-P(3,2);%UU

P(1,3)=NE(i);%NE
P(2,3)=NU(i);%NU
P(3,3)=1-P(1,3)-P(2,3);%NN

[V,D]=eig(P);

tilD(1,1)=log(D(1,1));
tilD(2,2)=log(D(2,2));
tilD(3,3)=log(D(3,3));

Lam=V*tilD/V;

EUlam(i,1)=Lam(2,1);
ENlam(i,1)=Lam(3,1);
UElam(i,1)=Lam(1,2);
UNlam(i,1)=Lam(3,2);
NElam(i,1)=Lam(1,3);
NUlam(i,1)=Lam(2,3);

pee=P(1,1);
pjs=JS(i);
leu=Lam(2,1);
len=Lam(3,1);
r=0;
JSlamN(i,1)=fzero(@lamfun,pjs);
r=1;
JSlamP(i,1)=fzero(@lamfun,pjs);
r=0.37;
JSlamFM(i,1)=fzero(@lamfun,pjs);
end

