The Matlab program to make the time-aggregation adjustment in "The Cyclicality of Job-to-Job Transitions and Its Implications for Aggregate Productivity" by Toshihiko Mukoyama.

Main program:adjustment1.m

lamfun.m: function used in the main program

seven files as input (XXvectsa.m)

The input files are the monthly flow rates taken from Fallick and Fleishman website (http://www.federalreserve.gov/pubs/feds/2004/200434/200434abs.html) and seasonally adjusted.

The output:
JSlamN: Poisson probability for job-to-job transition with no recalls
JSlamP: Poisson probability for job-to-job transition with perfect recalls
JSlamFM: Poisson probability for job-to-job transition with r=0.37, following Fujita and Moscarini

XXlam: Poisson probability for XX flow. (The adjustment method follows Shimer (2012, RED).)

The graphs in the paper is based on the monthly probability (p=1-exp(-lambda)) and taking quarterly average.

