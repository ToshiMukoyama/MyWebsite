function [F]=lamfun(x)
global r pjs pee leu len;

F=x*exp(-(x+leu+len))+(1-r)*(pee-exp(-(x+leu+len))-x*exp(-(x+leu+len)))-pjs;