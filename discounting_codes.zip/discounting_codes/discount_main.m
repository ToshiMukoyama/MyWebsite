
%main program for "A Note on Cyclical Discount Factors and Labor Market
%Volatility"  (accompanies "myfun.m" and "hpfilter.m") by T. Mukoyama


clear all;

global chi lw S eta pi xi gama P y h sig btaw btaf lf

%initial guesses
init1=1
init2=1

%parameters other tha discount factor

% elasticity of matching function
eta = 0.72;
% worker bargaining power
gama = 0.72;
% matching function scale
chi = 0.6;
% home production
h = 0.4;
% productivity 
%(Note: in the paper, both productivity and discounting fluctuate together)
%y(1) = 1.0;
%y(2) = 1.0;
y(1) = 0.98;
y(2) = 1.02;

%transition matrix
pi(1,1)=0.9375;
pi(1,2)=1-pi(1,1);
pi(2,2)=0.9375;
pi(2,1)=1-pi(2,2);
P=pi(1,1)*pi(2,2)-pi(1,2)*pi(2,1);

%separation shock
sig = 0.05;



% iterate for various different values of bta(b) 
%(for either firm or worker)

for ibta=1:100
    

%first, find the solution for equations (5), (6), (7)
    
    
    
    % discount factor in "bad times": move 0.5 to 0.995
    disc(ibta)=0.5+0.005*(ibta-1);
    
% discount factors - note that this is for Figure 1 in the paper
btaw(1) = 0.995;
btaw(2) = 0.995;
btaf(1) = disc(ibta);
btaf(2) = 0.995;
%for Figure 2, use the follwing insead
%btaw(1) = disc(ibta);
%btaw(2) = 0.995;
%btaf(1) = 0.995;
%btaf(2) = 0.995;

btawa=(btaw(1)+btaw(2))/2;
btafa=(btaf(1)+btaf(2))/2;

% vacancy cost
xi=(btafa*chi*(1-gama)*(1.0-h))/(1-btafa*(1-sig)*(1-gama)-btawa*(1-sig-chi)*gama);

% solve for theta
thetasol= fsolve(@myfun,[init1 init2])

init1=thetasol(1);
init2=thetasol(2);

lw(1)
lw(2)
lf(1)
lf(2)

for i=1:2
wage(i)=y(i)-(1-gama)*S(i)+btaf(i)*(1-sig)*(pi(i,2)*(1-gama)*S(2)+pi(i,1)*(1-gama)*S(1));
end





%Second, use the solution for simulation

udata(1)=0.069;
zdata(1)=2;

np=200000;

for t=1:np
    thetadata(t)=thetasol(zdata(t));
    vdata(t)=udata(t)*thetadata(t);
    wagedata(t)=wage(zdata(t)); %average wage
    ddata(t)=(1-udata(t))*(y(zdata(t))-wagedata(t))-xi*vdata(t);
    pdata(t)=(1-udata(t))*(1-gama)*S(zdata(t))-ddata(t);
    udata(t+1)=udata(t)+sig*(1-udata(t))-lw(zdata(t))*udata(t);
    outputdata(t)=(1-udata(t))*y(zdata(t))-xi*vdata(t);

    q=rand(1);
    if zdata(t)==1 %today is bad
        if q<pi(1,1)
            zdata(t+1)=1;
        else
            zdata(t+1)=2;
        end
    else %today is good
        if q<pi(2,2)
            zdata(t+1)=2;
        else
            zdata(t+1)=1;
        end
    end
  
end

% throw away the first 500
    zdata1=zdata(501:np);
    thetadata1=thetadata(501:np);
    vdata1=vdata(501:np);
    wagedata1=wagedata(501:np);
    ddata1=ddata(501:np);
    pdata1=pdata(501:np);
    udata1=udata(501:np);
    outputdata1=outputdata(501:np);
ib=1;
ig=1;
for t=1:np-500
    if zdata1(t)==1
        thetab(ib)=thetadata1(t);
        vb(ib)=vdata1(t);
        wageb(ib)=wagedata1(t);
        db(ib)=ddata1(t);
        pb(ib)=pdata1(t);
        ub(ib)=udata1(t);
        ib=ib+1;
    else
        thetag(ig)=thetadata1(t);
        vg(ig)=vdata1(t);
        wageg(ig)=wagedata1(t);
        dg(ig)=ddata1(t);
        pg(ig)=pdata1(t);
        ug(ig)=udata1(t);
        ig=ig+1;
    end
end

i=1;
for t=1:2:2000
    outq(i)=outputdata1(t)+outputdata1(t+1);
    pq(i)=pdata1(t);
    i=i+1;
end

% average unemployment rate for "good" state and "bad" state
uavgb=mean(ub);
uavgg=mean(ug);

% percent deviations of various variables
vperb=(mean(vb)-mean(vdata1))/mean(vdata1);
vperg=(mean(vg)-mean(vdata1))/mean(vdata1);

thetaperb=(mean(thetab)-mean(thetadata1))/mean(thetadata1);
thetaperg=(mean(thetag)-mean(thetadata1))/mean(thetadata1);

pperb=(mean(pb)-mean(pdata1))/mean(pdata1);
pperg=(mean(pg)-mean(pdata1))/mean(pdata1);

dperb=(mean(db)-mean(ddata1))/mean(ddata1);
dperg=(mean(dg)-mean(ddata1))/mean(ddata1);

wageperb=(mean(wageb)-mean(wagedata1))/mean(wagedata1);
wageperg=(mean(wageg)-mean(wagedata1))/mean(wagedata1);

%main output for figures
UAG(ibta)=uavgg;
UAB(ibta)=uavgb;

%other statistics
toutq=hpfilter(log(outq),1600);
foutq=log(outq)-toutq';
tpq=hpfilter(log(pq),1600);
fpq=log(pq)-tpq';
DD(ibta)=dperg-dperb;
PD(ibta)=pperg-pperb;
stdy(ibta)=std(foutq);
stdp(ibta)=std(fpq);
stdratio(ibta)=stdp(ibta)/stdy(ibta);




end

% plotting
figure(1)
plot(disc,UAG,'r')
hold on
plot(disc,UAB,'b')

