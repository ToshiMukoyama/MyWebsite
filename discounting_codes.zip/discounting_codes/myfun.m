function F = myfun(x)
global chi lf lw S eta pi xi gama P y h sig btaw btaf

lf(1)=chi*(x(1)^(-eta));
lf(2)=chi*(x(2)^(-eta));
lw(1)=chi*(x(1)^(1-eta));
lw(2)=chi*(x(2)^(1-eta));


%equation below (6) in the paper

XX(1)=xi/(btaf(1)*lf(1)*(1-gama));
XX(2)=xi/(btaf(2)*lf(2)*(1-gama));


%equations (5) (6) in the paper

S(1)=(pi(2,2)*XX(1)-pi(1,2)*XX(2))/P;
S(2)=(pi(1,1)*XX(2)-pi(2,1)*XX(1))/P;


%equation (7) in the paper

F = [y(1)-h+(pi(1,2)*S(2)+pi(1,1)*S(1))*(btaf(1)*(1-sig)*(1-gama)+btaw(1)*(1-sig-lw(1))*gama)-S(1)
    y(2)-h+(pi(2,2)*S(2)+pi(2,1)*S(1))*(btaf(2)*(1-sig)*(1-gama)+btaw(2)*(1-sig-lw(2))*gama)-S(2)];
 