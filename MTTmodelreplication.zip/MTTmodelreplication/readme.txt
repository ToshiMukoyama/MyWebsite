Program files for the model part of "Occupational Reallocation within and across Firms: Implications for Labor Market Polarization"
Toshihiko Mukoyama, Naoki Takayama, Satoshi Tanaka

1. Program Files in ./code_fortran
(1) Purpose
The program consisting of these files solves the model.

(2) Software requirement
Fortran 90/95 Compiler and Powell's BOBYQA optimization package for Fortran are required. The authors use Intel Fortran Compiler Classic 2021.8.0.

(3) File structure
Main.f90 is the entry point for the program.
Initialize.f90 sets parameter values and other configurations.

(4) Input/Output interface
This program can import parameter values from ./input/parameter.txt if selected. If not selected, the corresponding parameter values must be specified in Initialize.f90.
This program saves the log and results in ./output/Logfile.txt and ./output/Results.txt respectively. It also saves new parameter values in ./output/parameter.txt if selected.

2. Program Files in ./code_stata
(1) Purpose
The program generates figures and tables, given the results from empirics and the above program.

(2) Software requirement
Stata is required. The authors use Stata 18.

(3) File structure
graph_model.do is the entry point.

(4) Input/Output interface
This program imports data from ./input/graph_model.xlsx. The results from empirics and the above program must be copied to this file.
This program saves the log and figures in .png format in ./output folder. 
