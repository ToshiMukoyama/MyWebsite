clear;

load Ydata.txt
load Ldata.txt 
load Idata.txt
load Cdata.txt 
load proddata.txt

load Udata.txt
load Zdata.txt
load vdata.txt
load tetadata.txt

Yseries=Ydata;
Lseries=Ldata;
Iseries=Idata;
Cseries=Cdata;
LPseries=proddata;

useries=Udata;
zseries=Zdata;
vseries=vdata;
thetaseries=tetadata;

Nperiods=length(Yseries);

%convert to quarterly
j = 1;
for i=1:3:Nperiods-2
  Y(j) = mean(Yseries(i:i+2));
  L(j) = mean(Lseries(i:i+2));
  I(j) = mean(Iseries(i:i+2));
  C(j) = mean(Cseries(i:i+2));
  LP(j) = mean(LPseries(i:i+2));
    
  urate(j) = mean(useries(i:i+2));
  vacancy(j) = mean(vseries(i:i+2));
  theta(j) = mean(thetaseries(i:i+2));
  prod(j) = mean(zseries(i:i+2));
  j = j+1;
end 

trends_Y = hpfilt(log(Y), 1600);
cyclical_Y = log(Y)-trends_Y' ;
std_Y = std(cyclical_Y)
autocorr_Y= corrcoef(cyclical_Y(1:end-1),cyclical_Y(2:end));

trends_L = hpfilt(log(L), 1600);
cyclical_L = log(L)-trends_L' ;
std_L = std(cyclical_L)
autocorr_L= corrcoef(cyclical_L(1:end-1),cyclical_L(2:end));

trends_I = hpfilt(log(I), 1600);
cyclical_I = log(I)-trends_I' ;
std_I = std(cyclical_I)
autocorr_I= corrcoef(cyclical_I(1:end-1),cyclical_I(2:end));

trends_C = hpfilt(log(C), 1600);
cyclical_C = log(C)-trends_C' ;
std_C = std(cyclical_C)
autocorr_C= corrcoef(cyclical_C(1:end-1),cyclical_C(2:end));

trends_LP = hpfilt(log(LP), 1600);
cyclical_LP = log(LP)-trends_LP' ;
std_LP = std(cyclical_LP)
autocorr_LP= corrcoef(cyclical_LP(1:end-1),cyclical_LP(2:end));



trends_u = hpfilt(log(urate), 1600);
cyclical_u = log(urate)-trends_u' ;
std_u = std(cyclical_u)
autocorr_u= corrcoef(cyclical_u(1:end-1),cyclical_u(2:end));

trends_v = hpfilt(log(vacancy), 1600);
cyclical_v = log(vacancy)-trends_v' ;
std_v = std(cyclical_v)
autocorr_v= corrcoef(cyclical_v(1:end-1),cyclical_v(2:end));

trends_th = hpfilt(log(theta), 1600);
cyclical_th = log(theta)-trends_th' ;
std_th = std(cyclical_th)
autocorr_th= corrcoef(cyclical_th(1:end-1),cyclical_th(2:end));

trends_z = hpfilt(log(prod), 1600);
cyclical_z = log(prod)-trends_z' ;
std_z = std(cyclical_z)
autocorr_z= corrcoef(cyclical_z(1:end-1),cyclical_z(2:end))

corruv= corrcoef(cyclical_u,cyclical_v);
corruth= corrcoef(cyclical_u,cyclical_th);
corruz= corrcoef(cyclical_u,cyclical_z);
corrvth= corrcoef(cyclical_v,cyclical_th);
corrvz= corrcoef(cyclical_v,cyclical_z);
corrthz= corrcoef(cyclical_th,cyclical_z);


corrYL= corrcoef(cyclical_Y,cyclical_L);
corrYC= corrcoef(cyclical_Y,cyclical_C);
corrYI= corrcoef(cyclical_Y,cyclical_I);
corrYLP= corrcoef(cyclical_Y,cyclical_LP);
corruLP= corrcoef(cyclical_u,cyclical_LP);
corrvLP= corrcoef(cyclical_v,cyclical_LP);
corrthLP= corrcoef(cyclical_th,cyclical_LP);

