clear;

%rigid wage case

%parameter values

bta = 0.996; %discount factor
gama = 0.72; %bargaining power parameter
sigma = 0.034;%separation rate
chi = 0.45; %matching function
eta = 0.72; %matching function
b = 0.4; %UI: 

%shock process
rho = 0.949; 
stdeps = 0.0065; 


%ss calculation
uss = sigma/(sigma+chi); %ss unemployment
vss = uss; %ss vacancy
thetass = 1.0; %ss theta
zss = 1.0; %ss productivity

%calibrate kappa
denomk = (1/(1-gama)-bta*(1-sigma-gama*chi)/(1-gama));
numk = bta*chi*(zss-b);
kappa= numk/denomk;



%elasticity for theta

telas = 1/(kappa*(1/(rho*bta)-(1-sigma))*eta/chi);


%Simulation

Nperiods=5000; %number of periods
Nskip=100; %number of skip

Periods=zeros(Nperiods+1,1);
useries=zeros(Nperiods+1,1);
vseries=zeros(Nperiods+1,1);
thetaseries=zeros(Nperiods+1,1);
jfprob=zeros(Nperiods+1,1);
zseries=zeros(Nperiods,1);


%log deviation
dthetaseries=zeros(Nperiods+1,1);
dzseries=zeros(Nperiods+1,1);

%initial condition
dzseries(1)=0; %first period 
zseries(1)=zss*exp(dzseries(1));
useries(1)=uss;
thetaseries(1)=thetass;
vseries(1)=thetaseries(1)*useries(1);
jfprob(1) = chi*(thetaseries(1)^(1-eta));
Periods(1)=1; %just counting periods 
rng('default')
shock=randn(Nperiods,1);

for i=1:Nperiods
    Periods(i+1)=i+1; %just counting
    useries(i+1)=sigma*(1-useries(i))+(1-jfprob(i))*useries(i); %unemployment transition
    dzseries(i+1)=rho*dzseries(i)+stdeps*shock(i,1); %AR(1) transition
    zseries(i)=zss*exp(dzseries(i)); % productivity level
    dthetaseries(i+1)=telas*dzseries(i+1); %theta determination
    thetaseries(i+1)=thetass*exp(dthetaseries(i)); %theta determination
    jfprob(i+1) = chi*(thetaseries(i+1)^(1-eta)); %job finding probability
    jfprob(i+1) = min(1,jfprob(i+1));
    jfprob(i+1) = min(thetaseries(i+1),jfprob(i+1));
    vseries(i+1)=thetaseries(i+1)*useries(i+1);
end

%convert to quarterly
j = 1;
for i=Nskip+1:3:Nperiods-2
  urate(j) = mean(useries(i:i+2));
  vacancy(j) = mean(vseries(i:i+2));
  theta(j) = mean(thetaseries(i:i+2));
  prod(j) = mean(zseries(i:i+2));
  j = j+1;
end 

trends_u = hpfilt(log(urate), 1600);
cyclical_u = log(urate)-trends_u' ;
std_u = std(cyclical_u)
autocorr_u= corrcoef(cyclical_u(1:end-1),cyclical_u(2:end));

trends_v = hpfilt(log(vacancy), 1600);
cyclical_v = log(vacancy)-trends_v' ;
std_v = std(cyclical_v);
autocorr_v= corrcoef(cyclical_v(1:end-1),cyclical_v(2:end));

trends_th = hpfilt(log(theta), 1600);
cyclical_th = log(theta)-trends_th' ;
std_th = std(cyclical_th);
autocorr_th= corrcoef(cyclical_th(1:end-1),cyclical_th(2:end));

trends_z = hpfilt(log(prod), 1600);
cyclical_z = log(prod)-trends_z' ;
std_z = std(cyclical_z)
autocorr_z= corrcoef(cyclical_z(1:end-1),cyclical_z(2:end))

corruv= corrcoef(cyclical_u,cyclical_v);
corruth= corrcoef(cyclical_u,cyclical_th);
corruz= corrcoef(cyclical_u,cyclical_z);
corrvth= corrcoef(cyclical_v,cyclical_th);
corrvz= corrcoef(cyclical_v,cyclical_z);
corrthz= corrcoef(cyclical_th,cyclical_z);

