clear all;

%year;
urateval;




hold on


startDate = datenum('01-01-1948')
endDate = datenum('07-01-2022')
xData = linspace(startDate,endDate,895);
p1=plot(xData,urate)


start=[datenum('11-01-1948') datenum('07-01-1953') datenum('08-01-1957') datenum('04-01-1960') datenum('12-01-1969') datenum('11-01-1973') datenum('01-01-1980') datenum('07-01-1981') datenum('07-01-1990') datenum('03-01-2001') datenum('12-01-2007') datenum('02-01-2020')];
finish=[datenum('10-01-1949') datenum('05-01-1954') datenum('04-01-1958') datenum('02-01-1961') datenum('11-01-1970') datenum('03-01-1975') datenum('07-01-1980') datenum('11-01-1982') datenum('03-01-1991') datenum('11-01-2001') datenum('06-01-2009') datenum('04-01-2020')];

colorstr=[0.8 0.8 0.8];
curax=axis;
y=[curax(3) curax(4) curax(4) curax(3)];

for i=1:length(start);
  x=[start(i) start(i) finish(i) finish(i)];
  fill(x,y,colorstr);
end;

set(gca,'XTick',xData)
datetick('x','yyyy')
%uistack(p1,'top');
uistack(p1,'top');

%h = findobj(gca,'Type','line');
%set(h,'EraseMode','xor');
h = findobj(gca,'Type','patch');
set(h,'EdgeColor','none');
%set(gca, 'Layer', 'top')
